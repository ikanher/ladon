# Pitfall corpus status

The 24-case corpus passed requirement-level independent review; see `reviews/final-review-20261110-r2.txt`. It covers six families with two fault and two control cases each. Every row binds a source span, formal subject, comparison goal and separate validation oracle where applicable. Pinned core and Mathlib builds, validation proofs, axiom receipts and all 24 restricted import checks passed. No case has been scored and no runtime baseline has been run; corpus acceptance does not establish detection performance.
