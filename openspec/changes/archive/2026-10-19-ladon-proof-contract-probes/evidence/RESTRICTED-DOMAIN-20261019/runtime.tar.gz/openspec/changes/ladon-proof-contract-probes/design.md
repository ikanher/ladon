# Design

## Context

See proposal.md. Existing Lean application checks and rational witnesses can test exact obligations. Quux ProbeSeparation proves a finite matrix example only; it does not provide a separating family for arbitrary mathematical statements.

## Goals / Non-Goals

**Goals:** turn contract differences into concrete downstream use questions with reproducible evidence. **Non-Goals:** interpret failure to find a term as a refutation, or infer general equivalence from a finite set of successful probes.

## Decisions

### Typed probe templates

Freeze five initial families: boundary regularity application; constant selection before a varying parameter; existential witness dependence; restricted-domain application; inequality-direction transfer. Each template carries exact source contract IDs, object map, desired application, scoped assumptions, expected observation kind and permitted checker. Templates use semantic feature identities, not paper names or equation numbers.

The first restricted-domain consumer is intentionally limited to `∀ x : Nat, P x` versus `∀ x : Nat, x ≤ 0 → P x`; its contract endpoint and conclusion must identify the exact AST predicate symbol. Broader subset/subtype and other guard profiles remain explicit unsupported cases.

A probe can yield checked application support, a checked counterexample to an implication, or an unresolved attempt. Comparing acceptance with failed elaboration can reveal a syntactic/application restriction, but alone does not prove semantic separation. Mark semantic distinguishing evidence only when the exact supported interpretation is checked on one side and an appropriate checked non-implication/counterexample is available on the other.

### Authority of agreement

Finite agreement reports survived-probe-family. It can become equivalence only with a replayed separating-family theorem for the exact object class, observation function and chosen family. The first delivery includes a tiny finite calibration with such a theorem and an unseparated pair that agrees on incomplete probes. This validates the boundary without claiming a separating basis for PDE estimates.

### Execution and findings

Reuse existing candidate workers, source-goal completion and rational_witness.py. No model API is required to run frozen probes; an LLM may propose additional terms as attributed attempts. The probe command emits the analysis probe variant and check-run/attempt-log references. Cache only exact subject/environment/template matches. At most 64 probes share the parent clock and 12 GiB worker cap; every attempt remains in the denominator.

Independent review receives original sources, exact goals and checker evidence without the proposed verdict. Valid transport, stronger-than-needed hypotheses and harmless alternate proof routes are required controls.

## Risks / Trade-offs

- Easy probes produce reassuring but irrelevant success → bind each probe to a specific contract feature and report its distinguishing scope.
- Witness search failures inflate fault counts → keep unresolved distinct from checked refutation throughout report projection.
- Probe-family completeness becomes a research project → require only the tiny separating-family calibration; general completeness is explicitly unsupported.
- Templates fail to distinguish even a simple family → stop after a 30-minute check of five faults and five matching controls; record which template remains unsupported.

## Migration Plan

Extend only the domain-owned probe variant and opt-in CLI branch. Historical findings keep their labels and authority. New checker runs never overwrite old first attempts or reviewer responses.

