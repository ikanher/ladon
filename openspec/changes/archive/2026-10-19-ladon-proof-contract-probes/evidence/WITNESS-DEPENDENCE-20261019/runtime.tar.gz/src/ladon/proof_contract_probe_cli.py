"""Ordinary additive CLI for source-bound application probes."""
from pathlib import Path

from .proof_contract_io import load_bounded_plans


def add_application_probe_parsers(subparsers):
    profile = subparsers.add_parser('probe-profile', help='Describe supported application-probe families')
    profile.add_argument('--output', type=Path)
    for operation in ('probe', 'check-probe'):
        parser = subparsers.add_parser(operation, help='Plan or check source-bound application probes')
        parser.add_argument('--input', type=Path, required=True)
        parser.add_argument('--output', type=Path)
        if operation == 'check-probe':
            parser.add_argument('--plan-id', required=True)
            parser.add_argument('--terms', type=Path, required=True)


def application_probe(args):
    from .proof_contract_probes import (
        application_probe_profile,
        check_application_probe,
        plan_application_probe,
    )

    if args.operation == 'probe-profile':
        return application_probe_profile()
    paths = [args.input] if args.operation == 'probe' else [args.input, args.terms]
    inputs = load_bounded_plans(paths, max_bytes=8 * 1024**2)
    if args.operation == 'probe':
        return plan_application_probe(inputs[0])
    return check_application_probe(inputs[0], args.plan_id, inputs[1])


def inspect_application_probe(artifact, context):
    """Pure semantic replay in a bounded worker; no source freshness claim."""
    import time

    from ._proof_contract_planned_source_inputs import _planned_input_size
    from .proof_contract_probes import _stage

    request = {'artifact': artifact, 'context': context}
    if _planned_input_size(request) > 8 * 1024**2:
        raise ValueError('probe inspection input exceeds 8 MiB')
    owned = {'deadlineMonotonic': time.monotonic() + 30,
        'limits': {'timeout_seconds': 30, 'max_output_bytes': 8 * 1024**2,
                   'max_rss_bytes': 12 * 1024**3}}
    checked = _stage('inspect-probe', request, owned)
    return checked['result'] if checked['status'] == 'completed' else checked
