"""Closed, aggregate-bounded public application-probe inputs."""
import copy
import math

from ._proof_contract_planned_source_inputs import _planned_input_size
from ._proof_contract_probe_pair import MAX_BYTES, probe_context, probe_side
from .proof_contract_bridge_supervision import bridge_limits
from .proof_contract_context_bridge import _DIGEST
from .proof_contract_payloads import closed


def probe_inputs(request, plan_id=None, terms=None, *, checking=False):
    from ._proof_contract_probe_templates import validate_template

    if _planned_input_size([request, plan_id, terms]) > MAX_BYTES:
        raise ValueError('aggregate application probe input exceeds 8 MiB')
    closed(request, {'repoRoot', 'context', 'left', 'right', 'template',
                     'deadlineMonotonic', 'limits'}, 'application probe request')
    if not isinstance(request['repoRoot'], str) or not request['repoRoot']:
        raise ValueError('probe requires a source repository path')
    deadline = request['deadlineMonotonic']
    if type(deadline) not in (int, float) or not math.isfinite(deadline):
        raise ValueError('application probe deadline must be finite')
    probe_context(request['context'])
    probe_side(request['left'])
    probe_side(request['right'])
    validate_template(request['template'])
    if checking:
        _check_terms(plan_id, terms)
    supplied = request['limits']
    defaults = {'timeout_seconds': 30, 'max_output_bytes': MAX_BYTES,
                'max_rss_bytes': 12 * 1024**3}
    if not isinstance(supplied, dict) or not set(supplied) <= set(defaults):
        raise ValueError('invalid application probe limits')
    limits = bridge_limits({**defaults, **supplied})
    limits['max_output_bytes'] = min(MAX_BYTES, limits['max_output_bytes'])
    owned = copy.deepcopy(request)
    owned['limits'] = limits
    return owned


def _check_terms(plan_id, terms):
    if not isinstance(plan_id, str) or not _DIGEST.fullmatch(plan_id):
        raise ValueError('application check requires an exact saved SHA-256 plan ID')
    if not isinstance(terms, dict) or not set(terms) <= {'formal-reading', 'probe'}:
        raise ValueError('terms may only name generated application-probe goals')
    for term in terms.values():
        if not isinstance(term, str) or not term.strip() or len(term.encode()) > 1024**2:
            raise ValueError('probe terms must be nonempty bounded strings')
