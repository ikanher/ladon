# Tasks

Current result: [finite calibration accepted](evidence/FINITE-CALIBRATION-30M-20261019/REPORT.md). The 30-minute calibration finished in 166.789 seconds: all ten controls behaved correctly, six actual Lean proof checks passed, and the deliberate memory stop ran last without retry. Task 1.3 is complete. All five typed families now have constructed source-bound discrepancy/control evidence: [regularity](evidence/REGULARITY-APPLICATION-20261019/REPORT.md), [constant uniformity](evidence/CONSTANT-UNIFORMITY-20261019/REPORT.md), [witness dependence](evidence/WITNESS-DEPENDENCE-20261019/REPORT.md), [restricted domain](evidence/RESTRICTED-DOMAIN-20261019/REPORT.md), and [inequality direction](evidence/INEQUALITY-DIRECTION-20261019/REPORT.md). The last family passed four actual Lean goals in 169.111 seconds and an independent audit accepted its exact Nat-order context restriction. Task 1.1 is complete; child progress is 2/8. Historical v1 selectors retain unsupported behavior. Task 1.2, execution/reuse, reviewer integration, and the broader five-fault/five-control feasibility gate remain open. The earlier failed 240-second qualification and full-run cutoff evidence remain preserved; the full repository regression was not rerun after recent scoped changes. Scoped strict quality, Ruff, strict OpenSpec validation and all 128 frozen-test records pass. A repository-wide strict-quality scan still reports C-grade complexity in the separate `src/ladon/_proof_contract_probe_domain_contracts.py`; it was not changed in this task. See [design](design.md), [capability contract](specs/ladon-contract-probes/spec.md), and [umbrella dependency table](../ladon-proof-contract-analysis-umbrella/design.md). No manuscript-error or whole-method claim follows; nothing was pushed.

## 1. Generate meaningful application probes

- [x] 1.1 Implement the five typed probe families with exact contract/template/context identities; verify one discrepancy and one matching control per family and document their distinguishing scope. [All five constructed discrepancy/control qualifications](evidence/INEQUALITY-DIRECTION-20261019/REPORT.md).
- [ ] 1.2 Reuse existing Lean application/source-goal and rational checker routes; verify failed elaboration, timeout and proof-search failure remain unresolved rather than semantic counterexamples.
- [x] 1.3 Add a tiny actual separating-family theorem and an incomplete-probe counterexample fixture; verify probe agreement implies equivalence only when the exact theorem and object class match. [Accepted finite calibration](evidence/FINITE-CALIBRATION-30M-20261019/REPORT.md).

## 2. Execute and review bounded probes

- [ ] 2.1 Implement bounded execution and exact-result reuse under the shared deadline; verify changed assumptions, source/environment drift and template revisions reject cached evidence.
- [ ] 2.2 Wire probe/inspect and sanitized reviewer export using original sources and checker receipts; verify first attempts and all failed/unsupported probes remain visible and proposed verdicts are omitted from reviewer inputs.
- [ ] 2.3 Run the 30-minute five-fault/five-control feasibility gate with real checker evidence; document unsupported templates and retain all attempts rather than expanding the family silently.

## 3. Deliver probe evidence

- [ ] 3.1 Verify valid domain transports and harmless method differences remain controls through investigation reporting; document application differences versus established semantic separation.
- [ ] 3.2 Run focused probe, checker, identity and independent-review regressions plus applicable quality checks; publish child acceptance evidence and the exact finite-agreement nonclaim.
