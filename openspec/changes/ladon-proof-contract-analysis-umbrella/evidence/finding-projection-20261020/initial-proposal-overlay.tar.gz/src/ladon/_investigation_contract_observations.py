"""Bounded native attachment projection for attributed investigation observations."""

import copy

from ladon.correspondence_interpretation import closed
from ladon.proofir_v3 import validate_envelope_batch

ATTACHMENT_KEYS = {"artifact", "context"}


def validate_contract_analysis(value):
    closed(value, ATTACHMENT_KEYS, "contract analysis attachment")
    context = value["context"]
    closed(context, {"artifacts"}, "contract analysis context")
    artifacts = context["artifacts"]
    if type(artifacts) is not list or not artifacts or len(artifacts) > 256:
        raise ValueError("invalid bounded contract analysis context")
    target = value["artifact"]
    if not isinstance(target, dict) or target.get("artifactKind") != "proofir.contract-analysis":
        raise ValueError("contract analysis artifact has the wrong kind")
    checked = validate_envelope_batch(copy.deepcopy(artifacts))
    target_id = target.get("artifactId")
    matches = [item.to_dict() for item in checked if item.to_dict().get("artifactId") == target_id]
    if len(matches) != 1 or matches[0] != target:
        raise ValueError("contract analysis artifact is absent or altered in its closed context")
    return copy.deepcopy(value)


def contract_dimensions(attachment, responses):
    from ladon.investigation_observations import review_relation

    return {
        "sourceFidelity": review_relation(responses, "sourceFidelity"),
        "extractionCompleteness": "not-established",
        "routeSupport": "not-established",
        "mathematicalFalsity": "not-established",
        "methodCorrespondence": review_relation(responses, "method"),
        "exploredPopulation": {
            "coverage": copy.deepcopy(attachment["artifact"]["coverage"]),
            "authority": "declared-child-coverage-only",
        },
    }


def project_contract_finding(finding, record, responses):
    attachment = record["contractAnalysis"]
    finding.update({
        "projectionSchema": "ladon-investigation-contract-finding-v1",
        "contractAnalysis": copy.deepcopy(attachment),
        "contractDimensions": contract_dimensions(attachment, responses),
    })
    return finding
