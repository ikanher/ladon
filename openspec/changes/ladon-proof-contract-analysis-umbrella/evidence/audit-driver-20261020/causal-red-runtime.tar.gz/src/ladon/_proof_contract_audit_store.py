"""Immutable run storage, checkpoint verification, and receipt helpers."""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

from ._proof_contract_audit_plan import _compact_bytes, _json_bytes, _resolve_refs, _sha
from .proof_contract_payloads import closed

RUN_SCHEMA = "ladon-contract-audit-run-v1"
INPUT_NAME = "run-inputs.json"
PLAN_NAME = "plan.json"
RUN_NAME = "run.json"
MAX_PLAN_BYTES = 8 * 1024**2
MAX_STAGE_BYTES = 8 * 1024**2
MAX_TOTAL_STAGE_BYTES = 32 * 1024**2

def _create_run(out, plan_bytes, plan, clock, runtime, source_binding, limits,
                copied_prefix=None):
    out.parent.mkdir(parents=True, exist_ok=True)
    out.mkdir()
    (out / "stages").mkdir()
    header = _input_header(plan_bytes, clock=clock, runtime=runtime,
                           source_binding=source_binding, limits=limits)
    _publish_no_clobber(out / INPUT_NAME, _json_bytes(header), MAX_PLAN_BYTES)
    _publish_no_clobber(out / PLAN_NAME, plan_bytes, MAX_PLAN_BYTES)
    if copied_prefix:
        for identifier, data in copied_prefix.items():
            _publish_no_clobber(out / "stages" / f"{identifier}.json", data, MAX_STAGE_BYTES)

def _input_header(plan_bytes, *, clock, runtime, source_binding, limits):
    return {"schema": "ladon-contract-audit-inputs-v1", "planDigest": _sha(plan_bytes),
            "clock": clock,
            "runtimeIdentity": runtime, "sourceBinding": source_binding, "limits": limits}

def _verify_header(header, expected, plan_bytes, prior_plan_bytes):
    closed(header, {"schema", "planDigest", "clock", "runtimeIdentity",
                    "sourceBinding", "limits"}, "audit resume header")
    if (header["schema"] != "ladon-contract-audit-inputs-v1"
            or header["planDigest"] != _sha(plan_bytes)
            or prior_plan_bytes != plan_bytes
            or header["runtimeIdentity"] != expected["runtimeIdentity"]
            or header["sourceBinding"] != expected["sourceBinding"]
            or header["limits"] != expected["limits"]):
        raise ValueError("audit resume plan, runtime, source binding or limits changed")

def _verified_prefix(prior, plan, header):
    run = _optional_json(prior / RUN_NAME, MAX_STAGE_BYTES)
    rows = _prior_rows(prior, plan, run, header)
    prefix, data_by_id, _results = _collect_prefix(prior, plan, rows, header)
    _reject_noncontiguous_artifacts(prior, plan, len(rows))
    return prefix, data_by_id

def _prior_rows(prior, plan, run, header):
    if run is not None:
        if run.get("schema") != RUN_SCHEMA or run.get("planDigest") != header["planDigest"]:
            raise ValueError("prior run receipt does not match its frozen plan")
        return run.get("stages", [])
    rows = []
    for stage in plan["stages"]:
        if not (prior / "stages" / f"{stage['id']}.json").exists():
            break
        rows.append({"id": stage["id"], "status": "completed"})
    return rows

def _collect_prefix(prior, plan, rows, header):
    prefix, data_by_id, results = [], {}, {}
    total = 0
    for index, record in enumerate(rows):
        if index >= len(plan["stages"]) or record.get("id") != plan["stages"][index]["id"]:
            raise ValueError("prior stage order does not match frozen plan")
        stage = plan["stages"][index]
        envelope, data, digest = _verified_stage(prior, stage, record, plan, header, results)
        identifier = stage["id"]
        results[identifier] = envelope["result"]
        envelope_digest = _sha(data)
        prefix.append({"id": identifier, "status": "completed", "resultDigest": digest,
                       "envelopeDigest": envelope_digest})
        data_by_id[identifier] = data
        total += len(data)
        if total > MAX_TOTAL_STAGE_BYTES:
            raise ValueError("prior stage results exceed 32 MiB")
    return prefix, data_by_id, results

def _verified_stage(prior, stage, record, plan, header, results):
    identifier = stage["id"]
    path = prior / "stages" / f"{identifier}.json"
    if path.is_symlink():
        raise ValueError("prior stage files may not be symlinks")
    data = path.read_bytes()
    if len(data) > MAX_STAGE_BYTES:
        raise ValueError("prior stage envelope exceeds 8 MiB")
    envelope = _decode_json(data)
    _validate_saved_stage(envelope, data, record, identifier)
    if envelope.get("status") != "completed" or record.get("status") not in {"completed", "reused"}:
        raise ValueError("only a successful completed stage prefix can be resumed")
    _validate_saved_request(envelope, stage, plan, header, results, identifier)
    return envelope, data, envelope["resultDigest"]

def _validate_saved_stage(envelope, data, record, identifier):
    digest = envelope.get("resultDigest")
    if envelope.get("id") != identifier or (record.get("resultDigest") is not None
            and digest != record.get("resultDigest")):
        raise ValueError("prior stage result or digest changed")
    if _sha(_json_bytes(envelope.get("result"))) != digest:
        raise ValueError("prior stage result or digest changed")
    if record.get("envelopeDigest") is not None and record["envelopeDigest"] != _sha(data):
        raise ValueError("prior stage envelope bytes changed")

def _validate_saved_request(envelope, stage, plan, header, results, identifier):
    request = _resolve_refs(stage["request"], results)
    expected = {"operation": stage["operation"], "request": request,
                "repoRoot": plan["repoRoot"], "sourceFiles": plan["sourceFiles"],
                "deadlineMonotonic": header["clock"]["deadlineMonotonic"],
                "deadlineUtc": header["clock"]["deadlineUtc"], "limits": plan["limits"]}
    if envelope.get("request") != expected:
        raise ValueError("prior stage request differs from the frozen plan and parent results")
    job = {"version": 1, "operation": "audit-stage", "request": expected,
           "analysisId": identifier, "deadlineObservation": None}
    if envelope.get("workerInputDigest") != "sha256:" + _sha(_compact_bytes(job)):
        raise ValueError("prior stage worker input digest changed")

def _reject_noncontiguous_artifacts(prior, plan, row_count):
    for stage in plan["stages"][row_count:]:
        path = prior / "stages" / f"{stage['id']}.json"
        if path.exists():
            raise ValueError("prior run has a stage artifact after a missing prefix entry")

def _verify_run_receipt(run, prefix, header):
    if (run.get("clock") != header["clock"] or run.get("runtimeIdentity") != header["runtimeIdentity"]
            or run.get("sourceBinding") != header["sourceBinding"] or run.get("bounds") != header["limits"]):
        raise ValueError("prior run receipt clock or identities differ from frozen inputs")
    expected = [{"id": row["id"], "status": "reused", "resultDigest": row["resultDigest"],
                 "envelopeDigest": row["envelopeDigest"]}
                for row in prefix]
    actual = [{"id": row["id"], "resultDigest": row["resultDigest"],
               "envelopeDigest": row.get("envelopeDigest")}
              for row in run.get("stages", [])]
    if len(actual) != len(expected) or any(a != {"id": b["id"], "resultDigest": b["resultDigest"],
                                                "envelopeDigest": b["envelopeDigest"]}
                                           for a, b in zip(actual, expected, strict=True)):
        raise ValueError("prior run receipt and immutable stage files disagree")

def _stage_envelope(stage, request, checked, result, status):
    digest = _sha(_json_bytes(result)) if result is not None else None
    return {"schema": "ladon-contract-audit-stage-v1", "id": stage["id"],
            "operation": stage["operation"], "status": status,
            "request": request, "workerInputDigest": checked.get("workerInputDigest"),
            "processReceipt": checked.get("processReceipt"), "result": result,
            "resultDigest": digest, "diagnostic": checked.get("diagnostic")}

def _store_stage(out, identifier, envelope, total):
    data = _json_bytes(envelope)
    if len(data) > MAX_STAGE_BYTES:
        raise ValueError("stored audit stage envelope exceeds 8 MiB")
    if total + len(data) > MAX_TOTAL_STAGE_BYTES:
        raise ValueError("stored audit stage results exceed 32 MiB")
    _publish_no_clobber(out / "stages" / f"{identifier}.json", data, MAX_STAGE_BYTES)
    return envelope["resultDigest"], len(data), _sha(data)

def _run_report(plan, clock, runtime, source_binding, stages, status, code, message):
    return {"schema": RUN_SCHEMA, "status": status, "code": code, "message": message,
            "planDigest": _sha(_json_bytes(plan)), "stages": stages,
            "clock": clock, "bounds": plan["limits"], "runtimeIdentity": runtime,
            "sourceBinding": source_binding, "remainingWork": len(plan["stages"]) - len(stages),
            "dimensions": {"sourceFidelity": "not-certified", "extractionCompleteness": "not-certified",
                           "routeSupport": "not-inferred", "methodCorrespondence": "not-inferred",
                           "mathematicalFalsity": "not-claimed", "exploredPopulation": "not-claimed"},
            "authority": "bounded orchestration only; stage result authority is unchanged"}

def _optional_json(path, maximum):
    if not path.exists():
        return None
    return _read_json(path, maximum)

def _read_json(path, maximum):
    if path.is_symlink():
        raise ValueError("audit run files may not be symlinks")
    with path.open("rb") as stream:
        raw = stream.read(maximum + 1)
    if len(raw) > maximum:
        raise ValueError("audit JSON file exceeds its byte limit")
    return _decode_json(raw)

def _decode_json(raw):
    from .proof_contract_io import _decode
    return _decode(raw)

def _reject_symlink_ancestors(path):
    current = path.parent
    while current != current.parent:
        if current.exists() and current.is_symlink():
            raise ValueError("output path may not traverse symlinks")
        current = current.parent

def _publish_no_clobber(path, data, maximum):
    if len(data) > maximum:
        raise ValueError("audit artifact exceeds its byte limit")
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp",
                                                  dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path, follow_symlinks=False)
        temporary.unlink()
        try:
            directory_fd = os.open(path.parent, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
