import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Analysis.Normed.Group.InfiniteSum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity

open Filter Finset
open scoped Topology

/-!
# Summable input and restoring drift

Robbins and Monro, *A stochastic approximation method* (1951), Section 3,
equations (14)–(20) and Lemma 1, show that a nonnegative mean-square error
converges to zero when summable input is opposed by nonsummable restoring
weights. This file proves the deterministic sequence argument in general form;
it does not construct a stochastic process or its conditional expectation.

The conventional proof is in
`latex/natural-language/historical_stochastic_approximation_root_energy.tex`.
-/

namespace Mf.Optimization.StochasticApproximation

/-- The accumulated input equals terminal energy plus accumulated dissipation,
after adding the initial energy. This identity includes the zero-length case. -/
theorem balance_sum (b c d : ℕ → ℝ)
    (hstep : ∀ n, b (n + 1) = b n + c n - d n) (N : ℕ) :
    b N + ∑ n ∈ range N, d n = b 0 + ∑ n ∈ range N, c n := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [sum_range_succ, sum_range_succ, hstep]
    linarith

/-- A nonnegative energy balance with nonnegative summable input has finite
accumulated dissipation and a finite nonnegative energy limit. -/
theorem summable_drift_and_limit (b c d : ℕ → ℝ)
    (hb : ∀ n, 0 ≤ b n) (hc : ∀ n, 0 ≤ c n) (hd : ∀ n, 0 ≤ d n)
    (hcSum : Summable c)
    (hstep : ∀ n, b (n + 1) = b n + c n - d n) :
    Summable d ∧ ∃ l : ℝ, 0 ≤ l ∧ Tendsto b atTop (𝓝 l) := by
  have hdSum : Summable d := summable_of_sum_range_le hd (c := b 0 + ∑' n, c n) (by
    intro N
    have hs := balance_sum b c d hstep N
    have hcBound := hcSum.sum_le_tsum (range N) (fun n _ => hc n)
    linarith [hb N])
  have ht : Tendsto b atTop (𝓝 (b 0 + ∑' n, c n - ∑' n, d n)) := by
    have heq : b = fun N => b 0 + ∑ n ∈ range N, c n - ∑ n ∈ range N, d n := by
      funext N
      linarith [balance_sum b c d hstep N]
    rw [heq]
    simp only [sum_range_zero, add_zero, sub_zero]
    exact (tendsto_const_nhds.add hcSum.hasSum.tendsto_sum_nat).sub
      hdSum.hasSum.tendsto_sum_nat
  exact ⟨hdSum, _, ge_of_tendsto ht (Eventually.of_forall hb), ht⟩

/-- A finite nonnegative state limit and summable restoring work force that
limit to zero when its nonnegative weights are not summable. No balance
identity or convergence in expectation is required. -/
theorem tendsto_zero_of_convergent_restoration (b d w : ℕ → ℝ)
    (hw : ∀ n, 0 ≤ w n) (hwSum : ¬ Summable w) (hdSum : Summable d)
    (hrestore : ∀ n, w n * b n ≤ d n)
    (hlimit : ∃ l : ℝ, 0 ≤ l ∧ Tendsto b atTop (𝓝 l)) :
    Tendsto b atTop (𝓝 0) := by
  obtain ⟨l,hl,hlim⟩ := hlimit
  have hlzero : l = 0 := by
    by_contra hn
    have hlpos : 0 < l := lt_of_le_of_ne hl (Ne.symm hn)
    have hevent : ∀ᶠ n in atTop, l / 2 < b n :=
      hlim.eventually (eventually_gt_nhds (by linarith : l / 2 < l))
    have hwScaled : Summable (fun n => (l / 2) * w n) :=
      hdSum.of_norm_bounded_eventually_nat (hevent.mono (by
        intro n hn
        rw [Real.norm_eq_abs, abs_of_nonneg (mul_nonneg (by positivity) (hw n))]
        calc
          (l / 2) * w n ≤ w n * b n := by nlinarith [hw n]
          _ ≤ d n := hrestore n))
    have hw' := hwScaled.mul_left (l / 2)⁻¹
    have heq : (fun n => (l / 2)⁻¹ * ((l / 2) * w n)) = w := by
      funext n
      field_simp
    rw [heq] at hw'
    exact hwSum hw'
  simpa [hlzero] using hlim

/-- Persistent restoring weights force the energy limit to zero. The proof
uses eventual positivity of a hypothetical positive limit; it requires neither
monotonicity of the energy nor a uniform positive lower bound on the weights. -/
theorem tendsto_zero_of_restoring_balance (b c d w : ℕ → ℝ)
    (hb : ∀ n, 0 ≤ b n) (hc : ∀ n, 0 ≤ c n) (hd : ∀ n, 0 ≤ d n)
    (hw : ∀ n, 0 ≤ w n) (hcSum : Summable c) (hwSum : ¬ Summable w)
    (hrestore : ∀ n, w n * b n ≤ d n)
    (hstep : ∀ n, b (n + 1) = b n + c n - d n) :
    Tendsto b atTop (𝓝 0) := by
  obtain ⟨hdSum,hlimit⟩ := summable_drift_and_limit b c d hb hc hd hcSum hstep
  exact tendsto_zero_of_convergent_restoration b d w hw hwSum hdSum hrestore hlimit

/-- A descent inequality is converted into an exact nonnegative dissipation
balance. It gives both finite accumulated weighted energy and convergence to
zero when the nonnegative restoring weights are not summable. -/
theorem tendsto_zero_of_restoring_inequality (b c w : ℕ → ℝ)
    (hb : ∀ n, 0 ≤ b n) (hc : ∀ n, 0 ≤ c n) (hw : ∀ n, 0 ≤ w n)
    (hcSum : Summable c) (hwSum : ¬ Summable w)
    (hstep : ∀ n, b (n + 1) ≤ b n - w n * b n + c n) :
    Summable (fun n => w n * b n) ∧ Tendsto b atTop (𝓝 0) := by
  let d : ℕ → ℝ := fun n => b n + c n - b (n + 1)
  have hrestore (n : ℕ) : w n * b n ≤ d n := by dsimp [d]; linarith [hstep n]
  have hd (n : ℕ) : 0 ≤ d n := (mul_nonneg (hw n) (hb n)).trans (hrestore n)
  have heq (n : ℕ) : b (n + 1) = b n + c n - d n := by dsimp [d]; linarith
  have hdSum := (summable_drift_and_limit b c d hb hc hd hcSum heq).1
  exact ⟨Summable.of_nonneg_of_le (fun n => mul_nonneg (hw n) (hb n)) hrestore hdSum,
    tendsto_zero_of_restoring_balance b c d w hb hc hd hw hcSum hwSum hrestore heq⟩

/-- Summable input gives a finite nonnegative energy limit and summable weighted
energy even when the restoring weights themselves may be summable. -/
theorem summable_weighted_energy_and_limit (b c w : ℕ → ℝ)
    (hb : ∀ n, 0 ≤ b n) (hc : ∀ n, 0 ≤ c n) (hw : ∀ n, 0 ≤ w n)
    (hcSum : Summable c)
    (hstep : ∀ n, b (n + 1) ≤ b n - w n * b n + c n) :
    Summable (fun n => w n * b n) ∧ ∃ l : ℝ, 0 ≤ l ∧ Tendsto b atTop (𝓝 l) := by
  let d : ℕ → ℝ := fun n => b n + c n - b (n + 1)
  have hrestore (n : ℕ) : w n * b n ≤ d n := by dsimp [d]; linarith [hstep n]
  have hd (n : ℕ) : 0 ≤ d n := (mul_nonneg (hw n) (hb n)).trans (hrestore n)
  have heq (n : ℕ) : b (n + 1) = b n + c n - d n := by dsimp [d]; linarith
  obtain ⟨hdSum, hlim⟩ := summable_drift_and_limit b c d hb hc hd hcSum heq
  exact ⟨Summable.of_nonneg_of_le (fun n => mul_nonneg (hw n) (hb n)) hrestore hdSum, hlim⟩

/-- The finite-limit and weighted-summability conclusions persist when the
nonnegative descent assumptions begin only after a fixed finite prefix. -/
theorem summable_weighted_energy_and_limit_after (b c w : ℕ → ℝ) (N : ℕ)
    (hb : ∀ n, N ≤ n → 0 ≤ b n) (hc : ∀ n, N ≤ n → 0 ≤ c n)
    (hw : ∀ n, N ≤ n → 0 ≤ w n) (hcSum : Summable c)
    (hstep : ∀ n, N ≤ n → b (n + 1) ≤ b n - w n * b n + c n) :
    Summable (fun n => w n * b n) ∧ ∃ l : ℝ, 0 ≤ l ∧ Tendsto b atTop (𝓝 l) := by
  have hshift := summable_weighted_energy_and_limit (fun n => b (n+N))
    (fun n => c (n+N)) (fun n => w (n+N))
    (fun n => hb _ (Nat.le_add_left _ _)) (fun n => hc _ (Nat.le_add_left _ _))
    (fun n => hw _ (Nat.le_add_left _ _)) ((summable_nat_add_iff N).mpr hcSum)
    (fun n => by simpa [Nat.add_right_comm] using hstep (n+N) (Nat.le_add_left _ _))
  obtain ⟨hs, l, hl, hlim⟩ := hshift
  exact ⟨(summable_nat_add_iff N).mp hs, l, hl, (tendsto_add_atTop_iff_nat N).mp hlim⟩

/-- Nonsummable restoring weights force the original energy sequence to zero
even when its descent inequality and sign assumptions hold only after age `N`. -/
theorem tendsto_zero_of_restoring_inequality_after (b c w : ℕ → ℝ) (N : ℕ)
    (hb : ∀ n, N ≤ n → 0 ≤ b n) (hc : ∀ n, N ≤ n → 0 ≤ c n)
    (hw : ∀ n, N ≤ n → 0 ≤ w n) (hcSum : Summable c) (hwSum : ¬ Summable w)
    (hstep : ∀ n, N ≤ n → b (n + 1) ≤ b n - w n * b n + c n) :
    Summable (fun n => w n * b n) ∧ Tendsto b atTop (𝓝 0) := by
  have hshift := tendsto_zero_of_restoring_inequality (fun n => b (n+N))
    (fun n => c (n+N)) (fun n => w (n+N))
    (fun n => hb _ (Nat.le_add_left _ _)) (fun n => hc _ (Nat.le_add_left _ _))
    (fun n => hw _ (Nat.le_add_left _ _)) ((summable_nat_add_iff N).mpr hcSum)
    (fun hs => hwSum ((summable_nat_add_iff N).mp hs))
    (fun n => by simpa [Nat.add_right_comm] using hstep (n+N) (Nat.le_add_left _ _))
  exact ⟨(summable_nat_add_iff N).mp hshift.1, (tendsto_add_atTop_iff_nat N).mp hshift.2⟩

end Mf.Optimization.StochasticApproximation
