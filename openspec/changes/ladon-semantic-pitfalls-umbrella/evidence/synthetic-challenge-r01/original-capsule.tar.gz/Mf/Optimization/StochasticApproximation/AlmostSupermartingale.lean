import Mathlib.Probability.Martingale.Convergence

/-!
# Qualitative convergence and finite conditional descent

Herbert Robbins and David Siegmund, *A convergence theorem for non negative
almost supermartingales and some applications* (1971), connects summable
perturbations to almost-sure convergence. These supporting lemmas implement
two steps of the normalization/stopping proof presented by Morenikeji Neri
and Thomas Powell, *A quantitative Robbins–Siegmund theorem*,
arXiv:2410.15986v2, proof labelled `res:RS`.

A nonnegative supermartingale converges almost surely by the L¹-bounded
submartingale convergence theorem applied to its negative. A finite
conditional descent telescope keeps the actual terminal expectation.
-/

open MeasureTheory Filter
open scoped Topology ENNReal

namespace Mf.Optimization.StochasticApproximation

variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω} [IsProbabilityMeasure μ]

/-- Qualitative convergence needs no uniform-integrability assumption. -/
theorem nonnegative_supermartingale_converges (ℱ : Filtration ℕ mΩ)
    (X : ℕ → Ω → ℝ) (hX : Supermartingale X ℱ μ)
    (hn : ∀ n, ∀ᵐ ω ∂μ, 0 ≤ X n ω) :
    ∀ᵐ ω ∂μ, ∃ c : ℝ, 0 ≤ c ∧ Tendsto (fun n => X n ω) atTop (𝓝 c) := by
  have hb : ∀ n, eLpNorm ((-X) n) 1 μ ≤ ENNReal.ofReal (∫ ω, X 0 ω ∂μ) := by
    intro n
    change eLpNorm (fun ω => -(X n ω)) 1 μ ≤ _
    rw [eLpNorm_one_eq_lintegral_enorm,
      ← ofReal_integral_norm_eq_lintegral_enorm (f := fun ω => -(X n ω)) (hX.integrable n).neg]
    apply ENNReal.ofReal_le_ofReal
    calc
      (∫ ω, ‖(-X) n ω‖ ∂μ) = ∫ ω, X n ω ∂μ := by
        apply integral_congr_ae
        filter_upwards [hn n] with ω hω
        simp only [Pi.neg_apply, norm_neg, Real.norm_eq_abs, abs_of_nonneg hω]
      _ ≤ ∫ ω, X 0 ω ∂μ := by
        simpa using hX.setIntegral_le (Nat.zero_le n) MeasurableSet.univ
  have hc := hX.neg.exists_ae_tendsto_of_bdd
    (R := (∫ ω, X 0 ω ∂μ).toNNReal) (by simpa only [ENNReal.ofReal] using hb)
  filter_upwards [hc, ae_all_iff.mpr hn] with ω ⟨c, hc⟩ hnω
  have ht : Tendsto (fun n => X n ω) atTop (𝓝 (-c)) := by
    simpa using hc.neg
  exact ⟨-c, ge_of_tendsto ht (Eventually.of_forall hnω), ht⟩


/-- The actual finite terminal is retained in the conditional descent telescope. -/
theorem conditional_descent_finite (ℱ : Filtration ℕ mΩ)
    (X B C : ℕ → Ω → ℝ)
    (hX : ∀ n, Integrable (X n) μ) (hB : ∀ n, Integrable (B n) μ)
    (hC : ∀ n, Integrable (C n) μ)
    (hd : ∀ n, μ[X (n + 1) | ℱ n] ≤ᵐ[μ] fun ω => X n ω - B n ω + C n ω)
    (N : ℕ) :
    (∫ ω, X N ω ∂μ) + ∑ n ∈ Finset.range N, (∫ ω, B n ω ∂μ) ≤
      (∫ ω, X 0 ω ∂μ) + ∑ n ∈ Finset.range N, (∫ ω, C n ω ∂μ) := by
  have hs (n : ℕ) : (∫ ω, X (n+1) ω ∂μ) ≤
      (∫ ω, X n ω ∂μ) - (∫ ω, B n ω ∂μ) + (∫ ω, C n ω ∂μ) := by
    calc
      _ = ∫ ω, μ[X (n+1) | ℱ n] ω ∂μ := (integral_condExp (ℱ.le n)).symm
      _ ≤ ∫ ω, X n ω - B n ω + C n ω ∂μ :=
        integral_mono_ae integrable_condExp (((hX n).sub (hB n)).add (hC n)) (hd n)
      _ = _ := by
        rw [integral_add (f := fun ω => X n ω - B n ω)
          ((hX n).sub (hB n)) (hC n), integral_sub (hX n) (hB n)]
  induction N with
  | zero => simp
  | succ n ih =>
    simp only [Finset.sum_range_succ]
    linarith [hs n]


end Mf.Optimization.StochasticApproximation
