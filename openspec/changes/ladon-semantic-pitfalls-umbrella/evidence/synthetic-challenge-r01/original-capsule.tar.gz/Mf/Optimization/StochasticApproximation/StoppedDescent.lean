import Mf.Optimization.StochasticApproximation.AlmostSupermartingale
import Mathlib.Probability.Martingale.OptionalStopping
/-!
# Predictable-error localization without an overshoot payment

Herbert Robbins and David Siegmund, *A convergence theorem for non negative
almost supermartingales and some applications* (1971), motivates this
localization step. The inspected modern proof is Morenikeji Neri and Thomas
Powell, *A quantitative Robbins–Siegmund theorem*, arXiv:2410.15986v2,
proof `res:RS`. The original 1971 source remains an access gap in the project.

Stopping at the first excessive next error prefix retains the previous prefix.
After stopping, a deterministic shift makes the supermartingale nonnegative.
Countably many such stops and a pathwise finite envelope recover convergence
of the unstopped process. No integrable supremum or expectation-summable error
budget is assumed. Constructing the normalized descent process is separate.
-/

open MeasureTheory Set Filter
open scoped Topology
namespace Mf.Optimization.StochasticApproximation
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω} [IsProbabilityMeasure μ]
/-- Stopping preserves a supermartingale, by the existing submartingale theorem and negation. -/
theorem supermartingale_stopped (ℱ : Filtration ℕ mΩ) (M : ℕ → Ω → ℝ)
    (hM : Supermartingale M ℱ μ) (τ : Ω → ℕ∞) (hτ : IsStoppingTime ℱ τ) :
    Supermartingale (stoppedProcess M τ) ℱ μ := by
  have hs := (hM.neg.stoppedProcess hτ).neg
  have heq : -stoppedProcess (-M) τ = stoppedProcess M τ := by
    funext n ω
    simp [MeasureTheory.stoppedProcess]
  rw [heq] at hs
  exact hs
/-- Stopping at the NEXT error prefix excludes the overshoot from the retained prefix. -/
theorem stopped_error_prefix_le
    (Q : ℕ → Ω → ℝ) (K : ℝ) (hQ0 : ∀ ω, Q 0 ω ≤ K) (n : ℕ) (ω : Ω) :
    stoppedProcess Q (hittingAfter (fun j ω => Q (j + 1) ω) (Ioi K) 0) n ω ≤ K := by
  let τ := hittingAfter (fun j ω => Q (j + 1) ω) (Ioi K) 0
  change Q (min (n : ℕ∞) (τ ω)).untopA ω ≤ K
  by_cases hz : (min (n : ℕ∞) (τ ω)).untopA = 0
  · rw [hz]
    exact hQ0 ω
  obtain ⟨k,hk⟩ := Nat.exists_eq_add_one_of_ne_zero hz
  rw [hk]
  have hlt : (k : ℕ∞) < τ ω := by
    suffices hh : (k : ℕ∞) < min (n : ℕ∞) (τ ω) from hh.trans_le (min_le_right _ _)
    have htop : min (n : ℕ∞) (τ ω) ≠ ⊤ :=
      ne_top_of_le_ne_top (by simp) (min_le_left _ _)
    lift min (n : ℕ∞) (τ ω) to ℕ using htop with j
    simp only [untopD_coe_enat,Nat.cast_lt,gt_iff_lt] at *
    omega
  have hn := notMem_of_lt_hittingAfter hlt
  simpa only [Set.mem_Ioi,not_lt,zero_le,forall_const] using hn

/-- A predictable pathwise bounded lower envelope suffices for supermartingale convergence;
no integrable bound on the envelope's supremum is required. -/
theorem supermartingale_converges_of_predictable_lower_envelope
    (ℱ : Filtration ℕ mΩ) (M Q : ℕ → Ω → ℝ) (hM : Supermartingale M ℱ μ)
    (hQ : StronglyAdapted ℱ (fun n ω => Q (n + 1) ω))
    (hQ0 : ∀ ω, Q 0 ω = 0)
    (hlower : ∀ᵐ ω ∂μ, ∀ n, 0 ≤ M n ω + Q n ω)
    (hbounded : ∀ᵐ ω ∂μ, BddAbove (Set.range (fun n => Q n ω))) :
    ∀ᵐ ω ∂μ, ∃ c : ℝ, Tendsto (fun n => M n ω) atTop (𝓝 c) := by
  let τ : ℕ → Ω → ℕ∞ := fun K =>
    hittingAfter (fun n ω => Q (n + 1) ω) (Ioi (K : ℝ)) 0
  have hτ (K : ℕ) : IsStoppingTime ℱ (τ K) :=
    hQ.adapted.isStoppingTime_hittingAfter measurableSet_Ioi
  have hlocal : ∀ K : ℕ, ∀ᵐ ω ∂μ, ∃ c : ℝ,
      Tendsto (fun n => stoppedProcess M (τ K) n ω) atTop (𝓝 c) := by
    intro K
    have hs := supermartingale_stopped ℱ M hM (τ K) (hτ K)
    have hn : ∀ n, ∀ᵐ ω ∂μ, 0 ≤ stoppedProcess M (τ K) n ω + (K : ℝ) := by
      intro n
      filter_upwards [hlower] with ω hω
      have hb := stopped_error_prefix_le Q (K : ℝ)
        (fun ω => by rw [hQ0]; positivity) n ω
      have hm := hω (min (n : ℕ∞) (τ K ω)).untopA
      change Q (min (n : ℕ∞) (τ K ω)).untopA ω ≤ (K : ℝ) at hb
      change 0 ≤ M (min (n : ℕ∞) (τ K ω)).untopA ω + (K : ℝ)
      linarith
    have hc := nonnegative_supermartingale_converges ℱ
      (fun n ω => stoppedProcess M (τ K) n ω + (K : ℝ))
      (hs.add_martingale (martingale_const ℱ μ (K : ℝ))) hn
    filter_upwards [hc] with ω ⟨c,hc0,hc⟩
    refine ⟨c - K, ?_⟩
    simpa only [add_sub_cancel_right] using hc.sub_const (K : ℝ)
  filter_upwards [ae_all_iff.mpr hlocal,hbounded] with ω hlocalω hbω
  obtain ⟨R,hR⟩ := hbω
  obtain ⟨K,hK⟩ := exists_nat_gt R
  have hsmall : ∀ n, Q n ω < (K : ℝ) := by
    intro n
    exact (hR ⟨n,rfl⟩).trans_lt hK
  have htop : τ K ω = ⊤ := by
    apply hittingAfter_eq_top_iff.mpr
    intro j hj
    exact not_lt.mpr (hsmall (j + 1)).le
  obtain ⟨c,hc⟩ := hlocalω K
  refine ⟨c, ?_⟩
  have heq : ∀ n, stoppedProcess M (τ K) n ω = M n ω := by
    intro n
    apply stoppedProcess_eq_of_le
    rw [htop]
    exact le_top
  simpa only [heq] using hc

end Mf.Optimization.StochasticApproximation
