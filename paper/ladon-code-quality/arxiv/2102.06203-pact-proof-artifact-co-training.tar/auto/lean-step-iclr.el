(TeX-add-style-hook
 "lean-step-iclr"
 (lambda ()
   (setq TeX-command-extra-options
         "--shell-escape")
   (TeX-add-to-alist 'LaTeX-provided-package-options
                     '(("inputenc" "utf8") ("fontenc" "T1")))
   (add-to-list 'LaTeX-verbatim-environments-local "lstlisting")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "lstinline")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "href")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "hyperref")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "hyperimage")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "hyperbaseurl")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "nolinkurl")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "url")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "path")
   (add-to-list 'LaTeX-verbatim-macros-with-delims-local "lstinline")
   (add-to-list 'LaTeX-verbatim-macros-with-delims-local "path")
   (TeX-run-style-hooks
    "latex2e"
    "math_commands"
    "article"
    "art10"
    "iclr2022_conference"
    "times"
    "hyperref"
    "url"
    "inputenc"
    "fontenc"
    "booktabs"
    "amsfonts"
    "nicefrac"
    "microtype"
    "xcolor"
    "cprotect"
    "amsmath"
    "cleveref"
    "import"
    "appendix"
    "color"
    "listings"
    "stmaryrd"
    "upquote"
    "amssymb"
    "mathtools"
    "array"
    "etoolbox")
   (TeX-add-symbols
    '("TODO" 1)
    '("edward" 1)
    '("todo" 1)
    '("icode" 1)
    "theHalgorithm"
    "ie"
    "eg"
    "SR"
    "gptf"
    "rownumber"
    "fix"
    "new"
    "lstlanguagefiles")
   (LaTeX-add-labels
    "sec:intro"
    "sec:background"
    "sec:embed"
    "sec:experiments"
    "sec:discussion"
    "sec:acknowledgement"
    "sec:source_code"
    "sec:appendix_background"
    "sec:appendix_dataset"
    "sec:appendix_experiments"
    "sec:appendix_examples")
   (LaTeX-add-bibliographies)
   (LaTeX-add-counters
    "magicrownumbers")
   (LaTeX-add-color-definecolors
    "keywordcolor"
    "tacticcolor"
    "commentcolor"
    "symbolcolor"
    "sortcolor"
    "attributecolor"))
 :latex)

